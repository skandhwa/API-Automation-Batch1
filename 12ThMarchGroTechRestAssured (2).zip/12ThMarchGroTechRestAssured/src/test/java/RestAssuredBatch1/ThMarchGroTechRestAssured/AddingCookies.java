package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import Utilities.ReUsabaleMethods;

public class AddingCookies {

	public static void main(String[] args) {
		RestAssured.baseURI="http://postman-echo.com/cookies/set";
		
	String Response=	given().log().all().
			cookies(ReUsabaleMethods.getCookieData()).
			when().get().then().log().all().statusCode(200)
.extract().response().asString();
	
	System.out.println(Response);
	

		
		
		
	}

}
