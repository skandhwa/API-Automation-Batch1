package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class ParsingJsonArrayAndValidation {

	public static void main(String[] args) {
		
RestAssured.baseURI="https://reqres.in";
    

             int ActualID=7;
             String Actualfirst_name="Byron";


		String Response=	given().log().all().headers("Connection","keep-alive")
				.queryParam("page", "2")
				
				
				.when().get("api/users")
				
				.then().log().all().
				assertThat().statusCode(200).
				
				headers("Connection","keep-alive").
				extract().response().asString();
			
			System.out.println(Response);
			
			JsonPath js=new JsonPath(Response);
			
		int ExpectedID=	js.getInt("data[0].id");
		System.out.println(ExpectedID);
		
		Assert.assertEquals(ActualID, ActualID);
		
		
	String ExpectedFName=	js.getString("data[3].first_name");
	
	Assert.assertEquals(Actualfirst_name, ExpectedFName);
	
	
	int count=js.getInt("per_page");
	System.out.println("Per Page value is "+count);
		
	System.out.println("Test Case Passed");
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		

	}

}
