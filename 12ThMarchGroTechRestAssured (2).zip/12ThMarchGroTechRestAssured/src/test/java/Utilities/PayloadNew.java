package Utilities;

public class PayloadNew {
	
	public static String AddPayload(String name,String leader)
	{
		
		String Payload="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+leader+"\"\r\n"
				+ "}";
		
		return Payload;
		
	}
	
	
	public static String AddBook(String ISBN,int aisle)
	{
		String Payload1="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with gggg\",\r\n"
				+ "\"isbn\":\""+ISBN+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}";
		
		return Payload1;
		
	}
	

}
