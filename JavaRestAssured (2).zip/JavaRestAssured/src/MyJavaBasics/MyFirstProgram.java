package MyJavaBasics;

public class MyFirstProgram {
	
	
	
	
	int add()
	{
		int a=20;
		int b=30;
		int c=a+b;
		return c;
	}
	
	public static void main(String[] args) {
		
		
		
		MyFirstProgram obj=new MyFirstProgram();
		System.out.println( obj.add());   
		
		
		System.out.println("Hello");
		
		
		

	}

}
