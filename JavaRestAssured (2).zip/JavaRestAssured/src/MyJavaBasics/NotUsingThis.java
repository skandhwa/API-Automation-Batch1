package MyJavaBasics;

class Student3
{
	int rollno;
	String name;
	float fees;
	
	Student3(int rollno,String name,float fees)
	{
		this.rollno=rollno;
		this.name=name;
		this.fees=fees;
	}
	
	
		void display()
		{
			System.out.println(rollno+" "+name+" "+fees);
		}
	
	
}
public class NotUsingThis {

	public static void main(String[] args) {
		
		Student3 obj=new Student3(234,"Manoj",45.65f);
		obj.display();

	}

}
