package MyJavaBasics;

public class NestedIfLoops {

	public static void main(String[] args) {
		
		int a=20,b=30,c=40;
		
		
		if(a<b)
		{
			if(b>c)
			{
				if(c<a)
				{
					System.out.println("This is true");
				}
			}
		}
		
		else
		{
			System.out.println("This is false");
		}
		

	}

}
