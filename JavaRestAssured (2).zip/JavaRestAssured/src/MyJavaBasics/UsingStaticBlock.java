package MyJavaBasics;

public class UsingStaticBlock {
	
	static
	{
		System.out.println("Hello How are you");
	}
	
	

	public static void main(String[] args) {
		
		System.out.println("I am main method");
		

	}

}
