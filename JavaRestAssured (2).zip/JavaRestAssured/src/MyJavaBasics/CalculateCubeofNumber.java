package MyJavaBasics;

class Calculate
{
	static int cube(int x)
	{
		return x*x*x;
	}
}




public class CalculateCubeofNumber {

	public static void main(String[] args) {
		
	System.out.println(Calculate.cube(5));	
		
		

	}

}
