package MyJavaBasics;

import java.util.Scanner;

public class WhileLoopExample {

	public static void main(String[] args) {
		
		int num;
		int rev=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number");
		num=sc.nextInt();
		
		int x=num;
		
		while(num!=0)///83!=0//8!=0
		{
			int r= num%10;///4//r=83%10=3///r=8
		rev=	rev*10+r;//4///4*10+3=43///43*10+8=438
		num=num/10;///83//8//0
			
			
		}
		
		System.out.println("The reverse of number is "+rev);
		
		if(x==rev)
		{
			System.out.println("The number is palindrome");
		}
		else
		{
			System.out.println("The number is not palindrome");
		}
		
		

	}

}
