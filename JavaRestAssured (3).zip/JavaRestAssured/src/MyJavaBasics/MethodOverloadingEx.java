package MyJavaBasics;

class Maths
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static int add(int x,int y,int z)
	{
		return x+y+z;
	}
}



public class MethodOverloadingEx {

	public static void main(String[] args) {
		
	System.out.println(Maths.add(45,67,88));	
	System.out.println(Maths.add(55,167,88));	

	}

}
