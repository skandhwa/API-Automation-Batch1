package MyJavaBasics;

public class DoWhileLoopExample2 {

	public static void main(String[] args) {
		
		
		do
		{
			System.out.println("Hello");
		}
		
		while(true);
		

	}

}
