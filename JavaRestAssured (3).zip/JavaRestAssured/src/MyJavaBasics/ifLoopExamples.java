package MyJavaBasics;

public class ifLoopExamples {

	public static void main(String[] args) {
		
//		int x=450,y=50,z=60;
//		if(x<y && y<z )
//		{
//			System.out.println("True");
//			
//			
//			
//		}
//		else
//		{
//			System.out.println("false");
//		}
//		
		
		int x=8/10;
		System.out.println(x);
//
	}

}
