package MyJavaBasics;

class Student2
{
	int rollno;
	String name;
	static String college="NIT";
	
	Student2(int r,String n)
	{
		rollno=r;
		name=n;
	}
	
	
	static void change()
	{
		college="IIT";
	}
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+college);
	}
	
}

public class UsingStaticMethod {

	public static void main(String[] args) {
		
		Student2.change();
		
		Student2 obj=new Student2(1234,"Harsh");
		obj.display();
		
		

	}

}
