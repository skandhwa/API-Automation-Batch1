package MyJavaBasics;


class Animal2
{
	void eat()
	{
		System.out.println("Animal Eats");
	}
	
	void run()
	{
		System.out.println("Animal runs");
	}
}

class Dog extends Animal2
{
	
	void bark()
	{
		System.out.println("Animal Barks");
	}
	
	void run()
	{
		System.out.println("dog runs");
	}
	
}
class XYZ extends Dog
{
	void sleep()
	{
		System.out.println("Animal Sleeps");
	}
	void run()
	{
		System.out.println("XYZ runs");
	}
	
	void work2()
	{
		run();
		super.run();
		
	}

}
public class SingleLevelInheritance {

	public static void main(String[] args) {
		
		XYZ obj=new XYZ();
		obj.eat();
		obj.bark();
		obj.sleep();

	}

}
