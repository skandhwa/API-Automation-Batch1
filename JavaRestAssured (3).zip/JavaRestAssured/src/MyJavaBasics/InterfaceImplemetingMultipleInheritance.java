package MyJavaBasics;

interface A2
{
	void print();
}

interface A3
{
	void display();
}

class A11 implements A2,A3
{
	public void print()
	{
		System.out.println("This is Print method");
	}
	
	public void display()
	{
		System.out.println("This is display method");
	}
}

public class InterfaceImplemetingMultipleInheritance {

	public static void main(String[] args) {
		
		A2 ref=new A11();
		ref.print();
		A3 ref1=new A11();
		ref1.display();
		
		
		

	}

}
