package MyJavaBasics;

public class LeftShiftOperator {

	public static void main(String[] args) {
		
		
		System.out.println(10<<3);///10*2pow3
		System.out.println(20>>4);///20/2pow4
		
		
		
		System.out.println(12<<5);///
		System.out.println(30>>2);//30/4
		
		
		System.out.println(50>>3);///50/8
		
		
		int a=200;
		int b=35;
		
		
		int max= a>b ?a:b;
		
		System.out.println("Maximum is  "+max);
		
		int p=30;
		p*=5;//p=p*5=30*5=150
		System.out.println(p);
		
		int q=80;
		q-=20;//q=q-20=80-20=60
		System.out.println(q);
		
		
		
		
	}

}
