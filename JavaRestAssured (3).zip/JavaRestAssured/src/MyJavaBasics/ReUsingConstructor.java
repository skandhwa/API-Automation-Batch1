package MyJavaBasics;


class Student4
{
	int rollno;
	String name;
	float fees;
	String course;
	
	Student4(int rollno,String name,float fees)
	{
		this.rollno=rollno;
		this.name=name;
		this.fees=fees;
	}
	
	Student4(int rollno,String name,float fees,String course)
	{
		
		this(rollno,name,fees);
//		this.rollno=rollno;
//		this.name=name;
//		this.fees=fees;
		this.course=course;
		
	}
			void display()
		{
			System.out.println(rollno+" "+name+" "+fees+" "+course);
		}
	
	
}




public class ReUsingConstructor {

	public static void main(String[] args) {
		
		Student4 obj=new Student4(3456,"saurabh",7800.5f,"Java");
		obj.display();
		
		
		Student4 obj1=new Student4(3456,"saurabh",8000.5f);
		obj1.display();
		
		

	}

}
