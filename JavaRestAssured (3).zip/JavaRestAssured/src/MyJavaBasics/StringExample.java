package MyJavaBasics;

public class StringExample {

	public static void main(String[] args) {
		
		
		///By using string literal
		String str="India";/// first way to declare a string
		
		String []str1=new String[10];
		
		char[]ch= {'s','a','u','r'};
		String str2=new String(ch);
		
		String str3="saur";
		
		
		String str4="India";
		
	str4=	str4.concat("Republic");
		
		System.out.println(str4);
		
		//By using a new keyword
		String str5=new String("Welcome");
		
		
		

	}

}
