package MyJavaBasics;

final class Bike8
{
	void run()
	{
		System.out.println("Bike runs");
	}
}

class Honda extends Bike8
{
	void brake()
	{
		System.out.println("Honda has breaks");
	}
	
}
public class finalClassExample {

	public static void main(String[] args) {
		
		
		Honda obj=new Honda();
		obj.run();
		obj.brake();
		
	}

}
