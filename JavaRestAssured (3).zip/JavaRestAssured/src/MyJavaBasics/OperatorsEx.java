package MyJavaBasics;

public class OperatorsEx {

	public static void main(String[] args) {
		
		
		int x=5;
		int z=12;
		
		int y=x++  + ++z  + ++x;
		
		//    5+13+7
		
		System.out.println(y);
		
		
		int p=35;
		int q=4;
		int h=p/q;
		System.out.println(h);
		
		
		
		
		int x1=56;
		int y1=56;
		
	boolean flag=	x1==y1;
	System.out.println(flag);
		
		
		
		
		
		
		
		

	}

}
