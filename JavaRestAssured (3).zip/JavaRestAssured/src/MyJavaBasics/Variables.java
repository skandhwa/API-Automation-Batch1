package MyJavaBasics;

class Test
{
	int x=10;
	static int p=40;
	
	
	///instance variables
	
	void display()
	{
		int y=x+20;
		int q=p+40;
		
		
		
	}
	
	
	void test()
	{
		int z=x+20;
		
		
		
	}
}





public class Variables {

	public static void main(String[] args) {
		
		
		

	}

}
