/**
 * 
 */
/**
 * @author saura
 *
 */
module JavaRestAssured {
}