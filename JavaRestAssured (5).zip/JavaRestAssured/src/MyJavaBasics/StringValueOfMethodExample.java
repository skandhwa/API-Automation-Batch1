package MyJavaBasics;

public class StringValueOfMethodExample {

	public static void main(String[] args) {
		
		
		int x=30;
	String str=	String.valueOf(x);
	System.out.println(x);
		

	}

}
