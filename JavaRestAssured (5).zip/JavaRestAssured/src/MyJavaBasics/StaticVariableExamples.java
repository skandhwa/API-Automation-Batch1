package MyJavaBasics;


class Student
{
	int rollno;
	String name;
	static String college="NIT";
	
	Student(int r,String n)
	{
		rollno=r;
		name=n;
	}
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+college);
	}
	
}


public class StaticVariableExamples {

	public static void main(String[] args) {
		
		Student obj=new Student(23,"Manoj");
		Student obj1=new Student(43,"Harish");
		obj.display();
		obj1.display();
		
		

	}

}
