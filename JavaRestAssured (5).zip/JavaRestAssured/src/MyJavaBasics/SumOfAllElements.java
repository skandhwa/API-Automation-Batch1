package MyJavaBasics;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a= {34,56,78,99};
		int sum=0;
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		
		System.out.println(sum);
		

	}

}
