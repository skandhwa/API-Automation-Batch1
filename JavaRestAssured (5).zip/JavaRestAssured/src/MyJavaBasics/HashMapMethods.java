package MyJavaBasics;

import java.util.HashMap;
import java.util.Map;

public class HashMapMethods {

	public static void main(String[] args) {
		
		Map <Integer,String> mp=new HashMap<Integer,String>();
		mp.put(100,"Amit");
		mp.put(200,"Samit");
		mp.put(300,"Ramit");
		mp.put(400,"Rohit");
		mp.put(500,"Manan");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		
		
		Map <Integer,String> mp2=new HashMap<Integer,String>();
		mp.put(100,"Amit");
		mp.put(200,"Samit");
		mp.put(300,"Ramit");
		mp.put(400,"Rohit");
		mp.put(500,"Manan");
		
		for(Map.Entry x:mp2.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
//		mp.remove(100);
//		mp.remove(200,"Samit");
//		
		System.out.println();
		System.out.println();
//		
//		for(Map.Entry x:mp.entrySet())
//		{
//			System.out.print(x.getKey()+" ");
//			System.out.println(x.getValue());
//		}
//		
		
		mp.replace(100, "Prashant");
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		
	boolean flag=	mp.containsKey(200);
	System.out.println(flag);
	
	boolean flag1=mp.containsValue("Mohit");
	System.out.println(flag1);
	
	boolean flag3=mp.equals(mp2);
	System.out.println("Are both Maps Equal " +flag3);
	
	
		
		
		

	}

}
