package MyJavaBasics;

public class DowhileLoopExamples {

	public static void main(String[] args) {
		
		
		int i=5;
		
		do
		{
			System.out.println(i);//5//6//7//8//9
			i++;//5++//6++//9++
		}
		while(i<10);//6<10//7<10//10<10
		
		
		
		

	}

}
