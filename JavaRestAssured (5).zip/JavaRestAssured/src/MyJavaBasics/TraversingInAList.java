package MyJavaBasics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TraversingInAList {

	public static void main(String[] args) {
		
	List<String> li=new ArrayList<String>();
		
		li.add("car");
		li.add("cycle");
		li.add("Byk");
		li.add("");
		li.add("scooty");
		li.add(0,"jeep");
		
		
		Iterator<String> itr=li.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println("Traversing in Backward direction");
		
		ListIterator<String> itr1=li.listIterator();
		while(itr1.hasPrevious())
		{
			System.out.println(itr.next());
			System.out.println(itr1.previous());
		}
		
		
		
		
		
		

	}

}
