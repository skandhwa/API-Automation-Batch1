package MyJavaBasics;

import java.util.TreeSet;

public class TreeExample2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(67);
		s1.add(98);
		s1.add(23);
		s1.add(78);
		s1.add(213);
		
		
	int x=	s1.pollFirst();
		
	int y=	s1.pollLast();
	
	System.out.println(x);
	System.out.println(y);
		

	}

}
