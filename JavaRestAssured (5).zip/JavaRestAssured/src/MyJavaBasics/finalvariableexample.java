package MyJavaBasics;

class Car5
{
	final int speed=100;
	void run()
	{
		//speed=200;///A final variable cannot be changed
		System.out.println(speed);
	}
}

public class finalvariableexample {

	public static void main(String[] args) {
		
		Car5 obj=new Car5();
		obj.run();
		

	}

}
