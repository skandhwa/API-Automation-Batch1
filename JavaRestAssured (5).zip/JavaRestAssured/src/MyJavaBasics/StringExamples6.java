package MyJavaBasics;

public class StringExamples6 {

	public static void main(String[] args) {
		
//		String str="Republic";
//		
//	String str1=	str.substring(4);
//	
//	System.out.println(str1);
	
	
		
		String str="My Country is India";
		
	String []words=	str.split(" ");
	
	System.out.println(words[2]);
	
String str1=	str.replace("India", "England");
	
	
	System.out.println(str1);
	
	
	
	
	
	
		
		
		
		
		

	}

}
