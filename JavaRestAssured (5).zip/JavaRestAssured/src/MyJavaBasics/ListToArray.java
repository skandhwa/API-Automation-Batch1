package MyJavaBasics;

import java.util.ArrayList;
import java.util.List;

public class ListToArray {

	public static void main(String[] args) {
		
		
List<String> li=new ArrayList<String>();
		
		li.add("car");
		li.add("cycle");
		li.add("Byk");
		li.add("scooty");
		
		
	String []arr=	li.toArray(new String[0]);
	
	for(String x:arr)
		
	{
		System.out.println(x);
	}

	}

}
