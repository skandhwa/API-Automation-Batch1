package MyJavaBasics;

public class StringMethodsExample2 {

	public static void main(String[] args) {
		
		String str="My Name is India";
	String str1=	str.replace("is", "was");
	System.out.println(str1);
	
String str2=	str.replace(" ", "");
System.out.println(str2);


      String[]word= str.split(" ");
      for(String x:word)
      {
    	  System.out.println(x);
      }


		

	}

}
