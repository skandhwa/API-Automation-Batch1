package MyJavaBasics;

import java.util.TreeSet;

public class TreeExample3 {

	public static void main(String[] args) {
		
		TreeSet<String> t1=new TreeSet<String>();
		t1.add("A");
		t1.add("B");
		t1.add("C");
		t1.add("D");
		t1.add("E");
		
		System.out.println("Reverse of set is  "+t1.descendingSet());
		
		System.out.println("Headset is  "+t1.headSet("D",true));
		

		System.out.println("Tail is  "+t1.tailSet("B",true));
		System.out.println("Sub Set is  "+t1.subSet("B",false,"E",false));
		
		
	}

}
