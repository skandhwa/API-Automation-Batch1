package MyJavaBasics;

public class StringMethodsEx {

	public static void main(String[] args) {

      // String str="GroTech Minds";
       
       ///charAt
       
//     char ch=  str.charAt(2);
//     System.out.println(ch);
//     
//    int x= str.length();
//    System.out.println(x);
    
//   String str1= str.substring(5);
//   System.out.println(str1);
//   
//   String str2=str.substring(4,9);
//   System.out.println(str2);
       
       
//       String str1="India";
//       String str2="india";
//       
//     boolean flag=  str1.equalsIgnoreCase(str2);
//     System.out.println(flag);
//   
   
		
		String str="Saurabh";
	boolean flag=	str.isEmpty();
	System.out.println(flag);
	
	String str1=str.concat("Kandhway");
	System.out.println(str1);
   
   
    
    
		
		

	}

}
