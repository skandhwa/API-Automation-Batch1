package MyJavaBasics;

import java.util.Arrays;

public class StringAnagramExample {

	public static void main(String[] args) {
		
		String str1="Brag";
		String str2="grab";
		
	 str1=	str1.toLowerCase();
	 str2=	str2.toLowerCase();
	 
	 if(str1.length()!=str2.length())
	 {
		 System.out.println("Not Anagram as length is not equal");
	 }
	 
	 else
	 {
		char[]strarray1= str1.toCharArray();
		char[]strarray2=str2.toCharArray();
		Arrays.sort(strarray1);
		Arrays.sort(strarray2);
		
	boolean flag=	Arrays.equals(strarray1, strarray2);
	if(flag==true)
	{
		System.out.println("String are anagram");
	}
	else
	{
		System.out.println("Not Anagrams");
	}
		
	 }
		
		
		

	}

}
