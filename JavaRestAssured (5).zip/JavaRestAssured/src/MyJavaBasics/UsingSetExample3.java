package MyJavaBasics;

import java.util.HashSet;
import java.util.Set;

public class UsingSetExample3 {

	public static void main(String[] args) {
		Set<String> s1=new HashSet<String>();
		s1.add("car");		
		s1.add("byk");		
		s1.add("scooty");
		s1.add("truck");
		s1.add("Tata");
		
		 Set<String>s2=new HashSet<String>();
		 s2.add("Honda");
			s2.add("Tata");		
			s2.add("Kia");
			s2.add("Mahindra");
			
			s2.removeAll(s1);
			
			System.out.println(s2);

	}

}
