package MyJavaBasics;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetEx1 {

	public static void main(String[] args) {
		
		TreeSet<String> t1=new TreeSet<String>();
		t1.add("Jack");
		t1.add("Yuvan");
		t1.add("Amit");
		t1.add("Aakash");
		
		
//		for(String x:t1)
//		{
//			System.out.println(x);
//		}
		
		Iterator itr=t1.descendingIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		

	}

}
