package MyJavaBasics;

import java.util.HashMap;
import java.util.Map;

public class ArrayFrequency {

	public static void main(String[] args) {
		
		int []a= {10,20,20,20,10,30,20,10,30};
		int n=a.length;
		
		Map<Integer,Integer> mp=new HashMap<Integer,Integer>();
		
		for(int i=0;i<n;i++)//i=0,0<9...i=1,1<9,,i=2,2<9..i=3,3<9
		{
			if(mp.containsKey(a[i]))///mp.containsKey(a[2])
			{
				mp.put(a[i],mp.get(a[i])+1);///
			}
			else
			{
				mp.put(a[i],1);
			}
			
		}
		
		for(Map.Entry entry:mp.entrySet())
		{
			System.out.print(entry.getKey()+"  ");
			System.out.println(entry.getValue());
			
			
		}
		
		

	}

}
