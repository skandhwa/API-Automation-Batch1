package MyJavaBasics;

import java.util.LinkedHashSet;

public class LinkedHashSetExample {

	public static void main(String[] args) {
		
		LinkedHashSet<String> s1=new LinkedHashSet<String>();
		s1.add("car");
		s1.add("car");
		s1.add("byk");
		
		s1.add("scooty");
		s1.add("truck");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
	
		
		
		
		

	}

}
