package MyJavaBasics;

import java.util.LinkedList;
import java.util.List;

public class LinkedListExample {

	public static void main(String[] args) {
		
		List<String>li=new LinkedList<String>();
		
		li.add("car");
		li.add("byk");
		
		li.add("scooty");
		
		
List<String>li2=new LinkedList<String>();
		
		li2.add("truck");
		li2.add("jeep");
		li2.add("aeroplane");
		li2.add("scooter");
		
		
		li.addAll(li2);
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
	boolean flag=	li.contains("car");
		System.out.println(flag);
		
		li.retainAll(li2);
		
		System.out.println("After retaining the output is");
		System.out.println();
		
		for(String x:li)
		{
			System.out.println(x);
		}

        

	}

}
