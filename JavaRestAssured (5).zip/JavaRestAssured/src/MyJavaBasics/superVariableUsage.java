package MyJavaBasics;

class Animal5
{
	String colour="red";
}

class Dog3 extends Animal5
{
	String colour="white";
	void display()
	{
		System.out.println(super.colour);
	}
	
	
}
public class superVariableUsage {

	public static void main(String[] args) {
		
		Dog3 obj=new Dog3();
		obj.display();
	

	}

}
