package MyJavaBasics;

public class ReplacevsReplaceALL {

	public static void main(String[] args) {
		
//		String str="Nvidia";
//	String str1=	str.replace('N','v');
//	System.out.println(str1);
//	
//	String str2=new String("My .com is beginners site");
//	
//	String str3=str2.replaceAll(".com", ".net");
//	System.out.println(str3);
	
		
		String str="Index of is a method for finding index";
	int x=	str.indexOf("for");
	System.out.println(x);
		
		

	}

}
