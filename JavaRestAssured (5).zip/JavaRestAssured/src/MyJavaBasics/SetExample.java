package MyJavaBasics;

import java.util.HashSet;
import java.util.Set;

public class SetExample {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("car");
		s1.add("car");
		s1.add("byk");
		
		s1.add("scooty");
		s1.add("truck");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		s1.clear();
		
		boolean flag=s1.isEmpty();
		System.out.println(flag);
		

	}

}
