package MyJavaBasics;

public class JavGarbageCollectionEx {

	public static void main(String[] args) {
		
		JavGarbageCollectionEx obj=new JavGarbageCollectionEx();
		
		System.out.println(obj.hashCode());
		
		obj=null;
		
		
		System.gc();
		
		System.out.println("end of garbage collection");

	}
	
	protected void finalize()
	{
		System.out.println("Finalize getting called");
	}
	
	

}
