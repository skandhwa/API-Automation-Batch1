package MyJavaBasics;

public class JavaProgramFindmaxorMin {
	
	public static int fourthlargest(int []a,int n)
	{
		for(int i=0;i<n;i++)////i=0;0<6
		{
			for(int j=i+1;j<n;j++)//j=1;1<6,j=3,3<6
			{
				if(a[i]>a[j])///a[0]>a[1]//a[0]>a[2]//a[0]>a[3]
				{
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		}
		
		return a[n-4];
	}
	
	public static void main(String[] args) {
		
		int []a= {34,22,12,6,2,78,54};
		
	System.out.println(fourthlargest(a,7));	
		
		
		

	}

}
