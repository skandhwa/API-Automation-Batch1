package MyJavaBasics;

interface Print
{
	
	void display();
	void test();
	
}

class A10 implements Print
{
	
	
	public void display()
	{
		System.out.println("hello");
	}
	
	public void test()
	{
		System.out.println("how are you");
	}
	
	void message()
	{
		System.out.println("This is message");
	}
	
}

public class InterfaceExamples {

	public static void main(String[] args) {
		
//		A10 obj=new A10();
//		obj.test();
//		obj.display();
		
		Print ref=new A10();
		ref.display();
		ref.test();
		
		
		
		
	}

}
