package MyJavaBasics;

abstract class Bike10
{
	void display()
	{
		System.out.println("This is concrete method");
	}
	
	abstract void run();
	abstract void display2();
	
	void test()
	{
		System.out.println("I am test method");
	}
	
	void message()
	{
		System.out.println("I am message method");
	}
}

class Yamaha extends Bike10
{
	void run() 
	{
		System.out.println("Bike Runs");
	}

	void display2() 
	{
		System.out.println("I am display2");
	}
}





public class AbstractMethodExample {

	public static void main(String[] args) {
		
		Yamaha obj=new Yamaha();
		obj.run();
		obj.display();
		
		
		
		

	}

}
