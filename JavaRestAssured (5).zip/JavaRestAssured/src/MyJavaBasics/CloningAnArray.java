package MyJavaBasics;

import java.util.Arrays;

public class CloningAnArray {

	public static void main(String[] args) {
		
		int []a= {22,33,44,55};
		System.out.println("Elements of Original array are");
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		System.out.println();
		System.out.println();
		
		
		System.out.println("Elements of Cloned array are");
		int []c=a.clone();
		for(int x:c)
		{
			System.out.println(x);
		}
		
		
		boolean flag=Arrays.equals(a, c);
		System.out.println(flag);
		
		

	}

}
