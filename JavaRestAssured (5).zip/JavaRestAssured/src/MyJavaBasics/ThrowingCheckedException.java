package MyJavaBasics;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowingCheckedException {
	
	public static void method() throws FileNotFoundException
	{
		FileReader f=new FileReader("E:\\EclipseWorkspace\\Batch3Scratch\\src\\test\\java\\extent.properties");
		throw new FileNotFoundException();
	}
	
	
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		method();
		
		
		
		

	}

}
