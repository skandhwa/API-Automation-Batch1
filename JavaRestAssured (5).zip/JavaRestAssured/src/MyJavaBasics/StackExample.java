package MyJavaBasics;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.add(20);
		stk.add(30);
		stk.add(40);
		
		stk.pop();
		
		
		
		System.out.println(stk);
		

	}

}
