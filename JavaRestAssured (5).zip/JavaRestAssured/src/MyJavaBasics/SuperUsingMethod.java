package MyJavaBasics;

class Animal7
{
	void sleep()
	{
		System.out.println("Animal Sleeps");
	}
}

class Dog7 extends Animal7
{
	void eat()
	{
		System.out.println("Dog eats");
	}
	
	void sleep()
	{
		System.out.println("Dog sleeps");
	}
	
	void work()
	{
		eat();
		sleep();
		super.sleep();
		
	}
}

public class SuperUsingMethod {

	public static void main(String[] args) {
		
		Dog7 obj=new Dog7();
		obj.work();

	}

}
