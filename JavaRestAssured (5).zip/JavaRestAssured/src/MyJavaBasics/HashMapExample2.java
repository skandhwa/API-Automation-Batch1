package MyJavaBasics;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapExample2 {

	public static void main(String[] args) {
		
		
		Map <Integer,String> mp=new HashMap<Integer,String>();
		mp.put(100,"Amit");
		mp.put(200,"Samit");
		mp.put(300,"Ramit");
		mp.put(400,"Rohit");
		mp.put(500,"Manan");
		
		
		
		
		mp.putIfAbsent(501,"rakesh");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		
	System.out.println("Value at 100th Location is  "+mp.get(100));	;
		
	String str=	mp.toString();
	System.out.println(str);
	
	System.out.println();
	System.out.println();
	String str2=mp.get(100);
	System.out.println(str2);
	
	System.out.println();
	System.out.println();
	Set<Integer> s1=mp.keySet();
	System.out.println(s1);
	
	int x=mp.size();
	System.out.println(x);
	
	

	}

}
