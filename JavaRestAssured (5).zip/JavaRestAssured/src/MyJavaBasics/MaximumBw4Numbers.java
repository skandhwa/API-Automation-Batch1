package MyJavaBasics;

import java.util.Scanner;

public class MaximumBw4Numbers {

	public static void main(String[] args) {
		
		int a,b,c,d;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number");
		a=sc.nextInt();
		System.out.println("Enter the second number");
		b=sc.nextInt();
		System.out.println("Enter the third number");
		c=sc.nextInt();
		System.out.println("Enter the fourth number");
		d=sc.nextInt();
		
		if(a>b && a>c && a>d)
		{
			System.out.println("a is maximum");
		}
		else if(b>a && b>c && b>d)
		{
			System.out.println("b is maximum");
		}
		else if(c>a && c>b && c>d)
		{
			System.out.println("c is maximum");
		}
		else
		{
			System.out.println("d is maximum");
		}
		
		
		
		
		
		
		
		
		
		

	}

}
