package MyJavaBasics;

import java.util.HashMap;
import java.util.Map;

public class FrequencyofString {

	public static void main(String[] args) {
		
		String str="Tic tac toe toe tic tic";
	 str=	str.toLowerCase();
		Map<String,Integer> mp=new HashMap<String,Integer>();
		
	String []words=	str.split(" ");
	
	for(String x:words)
	{
		if(mp.containsKey(x))
		{
			mp.put(x,mp.get(x)+1);//mp.put(toe,2)
		}
		else
		{
			mp.put(x,1);
		}
	}
	
	for(Map.Entry entry:mp.entrySet())
	{
		System.out.print(entry.getKey()+"  ");
		System.out.println(entry.getValue());
		
		
	}
	
		
		
		

	}

}
