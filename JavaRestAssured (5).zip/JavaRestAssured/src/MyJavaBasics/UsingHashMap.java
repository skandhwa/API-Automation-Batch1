package MyJavaBasics;

import java.util.HashMap;
import java.util.Map;

public class UsingHashMap {

	public static void main(String[] args) {
	
		Map <Integer,String> mp=new HashMap<Integer,String>();
		mp.put(4,"Apple");
		mp.put(2,"Kiwi");
		mp.put(6,"Pines");
		mp.put(8,"Melon");
		mp.put(12,"Banana");
		mp.put(14,"Apple");
		mp.put(24,null);
		mp.put(null,"Grapes");
		mp.put(null,"pineapple");
		
	for(Map.Entry x:mp.entrySet())
	{
		System.out.print(x.getKey()+" ");
		System.out.println(x.getValue());
	}
		
		

	}

}
