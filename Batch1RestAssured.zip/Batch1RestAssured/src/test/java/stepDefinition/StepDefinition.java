package stepDefinition;

import Utilities.ReadDataFromProperty;
import static io.restassured.RestAssured.*;

import POJOMapper.CreateSerializeUser;
import io.cucumber.core.internal.com.fasterxml.jackson.core.JsonProcessingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class StepDefinition {
	
	RequestSpecification req;
	RequestSpecification res;
	ResponseSpecification respec;
	String strResponse;
	
	String PropertyFileData=ReadDataFromProperty.readDatafromProperty().getProperty("baseURI");
	
	
	@Given("User hits into the applicationurl with {string}")
	public void user_hits_into_the_applicationurl_with(String endpoint) {
		
		
		
		req=new RequestSpecBuilder().setBaseUri(PropertyFileData)
				.setContentType(ContentType.JSON).build();
		
	    
	}

	@Given("User will pass the payload")
	public void user_will_pass_the_payload() throws JsonProcessingException {
		
		res=given().spec(req).body(CreateSerializeUser.createUser());
	    
	}

	@When("User will submit the post request")
	public void user_will_submit_the_post_request() {
	   
	}

	@Then("validate the status code with {string}")
	public void validate_the_status_code_with(String string) {
	   
	}

	
	
	

}
