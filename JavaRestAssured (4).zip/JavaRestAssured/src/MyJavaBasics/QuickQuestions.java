package MyJavaBasics;

import java.util.LinkedList;
import java.util.List;

public class QuickQuestions {

	public static void main(String[] args) {
	
		
		  List<String>li=new LinkedList<String>();
			
			li.add("car");
			li.add("byk");		
			li.add("scooty");
			li.add("truck");
			
			li.set(4, "sedan");
			
			System.out.println(li);
			
			
			
			

	}

}
