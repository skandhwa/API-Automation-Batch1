package MyJavaBasics;

import java.util.Scanner;

public class TakingInputAsString {

	public static void main(String[] args) {
		
		
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		str=sc.nextLine();
		
	int x=	str.length();
	System.out.println("Length of string is "+x);
		

	}

}
