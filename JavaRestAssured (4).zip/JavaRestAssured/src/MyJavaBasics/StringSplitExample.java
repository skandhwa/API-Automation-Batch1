package MyJavaBasics;

public class StringSplitExample {

	public static void main(String[] args) {
		
		String str="Republic@Africais a vast continent";
	String []words=	str.split("@");
	
	String str1=words[0];
	System.out.println(str1);
	
	String str2=str1.substring(5);
	System.out.println(str2);
		
		
		

	}

}
