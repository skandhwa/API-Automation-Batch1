package MyJavaBasics;

public class ExceptionHandlingExample2 {

	public static void main(String[] args) {
		try
		{
		int []a=new int[4];
		a[6]=56;
		System.out.println(a[6]);
		
		
		
		int x=9/0;
		System.out.println(x);
		
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
		int p=20;
		int q=p+40;
		System.out.println(q);
		
		
		

	}

}
