package MyJavaBasics;

import java.util.LinkedList;
import java.util.List;

public class CollectionsExample2 {

	public static void main(String[] args) {
         List<String>li=new LinkedList<String>();
		
		li.add("car");
		li.add("byk");		
		li.add("scooty");
		li.add("truck");
		
		  List<String>li2=new LinkedList<String>();
			
		  li2.add("truck");
			li2.add("jeep");
			li2.add("aeroplane");
			li.add("car");
			
			
			
			
			li2.removeAll(li);
			
			System.out.println(li2);
			
			li2.remove(0);
			System.out.println();
			System.out.println(li2);
			
			
	}

}
