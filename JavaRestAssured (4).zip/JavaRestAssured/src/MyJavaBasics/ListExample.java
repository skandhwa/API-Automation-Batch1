package MyJavaBasics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		
		li.add("car");
		li.add("cycle");
		li.add("Byk");
		li.add("scooty");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
	System.out.println("Element at second index is "+li.get(2));	
	
	//li.set(4, "Truck");
	System.out.println("Printing the list with added element");
	
	for(String x:li)
	{
		System.out.println(x);
	}
	
	Collections.sort(li);
	System.out.println();
	System.out.println();
	System.out.println("After Sorting Element in List are ");
	
	for(String x:li)
	{
		System.out.println(x);
	}
		
		
		

	}

}
