package MyJavaBasics;

import java.util.Arrays;

public class ArrayMethodsEx {

	public static void main(String[] args) {
		
		int []a= {22,33,44,65};
		int[]b= {22,33,44,55};
		
		
	int k=	Arrays.mismatch(a,b);
	System.out.println("Mismatch at location "+k);
		
		int x=Arrays.compare(b,a);
		System.out.println(x);
		
	boolean flag=	Arrays.equals(a,b);
	System.out.println(flag);
	
	Arrays.sort(a);
		
	for(int z:a)
	{
		System.out.println(z);
	}
	
	
	int []p= {22,44,55,66};
	
	
String str=	Arrays.toString(p);
System.out.println(str);
	
		

	}

}
