package MyJavaBasics;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		Queue<String> q1=new PriorityQueue<String>();
		q1.add("Aman");
		q1.add("Manoj");
		q1.add("Taman");
		q1.add("Saroj");
		
		
		System.out.println(q1);
		
		q1.remove();
		
		System.out.println(q1);
		
		
		

	}

}
