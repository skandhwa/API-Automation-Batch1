package MyJavaBasics;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class UsingAddAllMethod {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("car");		
		s1.add("byk");		
		s1.add("scooty");
		s1.add("truck");
		s1.add("Tata");
		
		
//		Set<String> s2=new HashSet<String>();
//		
//		s2.add("truck");
//		s1.add("Honda");		
//		s1.add("Tata");		
//		s1.add("mahindra");
//		s1.add("Kia");
//		
//		s1.addAll(s2);
		   List<String>li=new LinkedList<String>();
			
			li.add("Honda");
			li.add("Tata");		
			li.add("Kia");
			li.add("Mahindra");
			li.add("Kia");
		
		
		
			s1.addAll(li);
			
		
		System.out.println(s1);
		
//		s1.clear();
//		
//		System.out.println(s1);
//		
		
		
		boolean flag=s1.contains("Kiay");
		System.out.println("is Kiay Present "+flag);
		
		
		

	}

}
