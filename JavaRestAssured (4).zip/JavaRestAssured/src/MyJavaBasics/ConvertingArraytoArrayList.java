package MyJavaBasics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConvertingArraytoArrayList {

	public static void main(String[] args) {
		
		String []a= {"Java","C#",".Net","PHP"};
	System.out.println(a);	
	
	System.out.println("After conversion the output is");
	
	List<String> li=new ArrayList<String>();
	
	System.out.println(Arrays.asList(a));
	
		

	}

}
