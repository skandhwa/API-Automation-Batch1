package MyJavaBasics;

public class ExceptionHandlingExample1 {

	public static void main(String[] args) throws InterruptedException {
		
//		int x=10;
//		int y=x/0;
//		System.out.println(y);
		
//		int []a=new int[4];
//		a[6]=56;
//		System.out.println(a[6]);
		
	//	Thread.sleep(3000);
		
		
		String str=null;
		int x=str.length();
		System.out.println(x);

		
		int p=20;
		int q=p+40;
		System.out.println(q);
		
		
		
		
	}

}
