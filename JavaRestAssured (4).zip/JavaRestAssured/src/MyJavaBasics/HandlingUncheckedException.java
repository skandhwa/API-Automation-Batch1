package MyJavaBasics;

public class HandlingUncheckedException {
	
	public static void checkAge(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("You are not elligible to vote");
		}
		
		else
		{
			System.out.println("Please cast your vote");
		}
	}
	

	public static void main(String[] args) {
		
		
		int n=200;
		checkAge(16);
		n+=1;
		System.out.println("Curret no of votes is  "+n);
		
		
		
		

	}

}
