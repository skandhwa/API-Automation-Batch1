package MyJavaBasics;

class Bank
{
	 int getROI(int x,int y)////A final method can never be overriden
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
}

class AXIS extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
}

public class MethodOverridingExample {

	public static void main(String[] args) {
		
		HDFC obj=new HDFC();
	System.out.println("HDFC rate of intrest is "+obj.getROI(2, 4));	
	
	AXIS obj1=new AXIS();
	System.out.println("Axis rate of intrest is "+obj.getROI(6, 8));	
	
	

	}

}
