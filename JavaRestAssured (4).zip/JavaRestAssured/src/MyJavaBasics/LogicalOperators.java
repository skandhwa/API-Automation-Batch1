package MyJavaBasics;

public class LogicalOperators {

	public static void main(String[] args) {
		
		
		int x=18;
		int y=18;
		int z=22;
		
	boolean flag2=	x!=y;
	System.out.println(flag2);
		
		
		if(x<y || z>y ||  x>z)//
		{
			System.out.println("I am true");
		}

	}

}
