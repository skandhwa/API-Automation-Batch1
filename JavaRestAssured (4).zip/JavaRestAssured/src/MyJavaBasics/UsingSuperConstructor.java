package MyJavaBasics;

class Animal8
{
	Animal8()
	{
		System.out.println("Animal is created here");
	}
}

class Dog8 extends Animal8
{
	Dog8()
	{
		super();
		System.out.println("Dog is created");
		
		
	}
}

public class UsingSuperConstructor {

	public static void main(String[] args) {
		
		Dog8 obj=new Dog8();
		
		
		

	}

}
