package MyJavaBasics;

import java.util.Scanner;

public class JavaSwitchCaseExample {

	public static void main(String[] args) {
		
		char operator;
		double num1,num2,result;
		Scanner sc=new Scanner(System.in);
		System.out.println("choose an operator");
		operator=sc.next().charAt(0);
		System.out.println("Enter the first number");
		num1=sc.nextDouble();
		
		System.out.println("Enter the second number");
		num2=sc.nextDouble();
		
		switch(operator)
		{
		
		case '+':
			
			result=num1+num2;
			System.out.println("The value is "+result);
			break;
			
		case '-':
			result=num1-num2;
			System.out.println("The value is "+result);
			break;
			
		case '*':
			result=num1*num2;
			System.out.println("The value is "+result);
			break;
			
		case '/':
			result=num1/num2;
			System.out.println("The value is "+result);
			break;
			
		default:
			System.out.println("Please enter a valid input");
			
		break;
		
		
		}
		
		
		

	}

}
