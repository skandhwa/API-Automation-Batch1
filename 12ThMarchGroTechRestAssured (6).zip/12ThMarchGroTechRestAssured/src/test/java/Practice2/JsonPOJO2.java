package Practice2;

public class JsonPOJO2 {
	
	public String firstname;
	
	public String lastname;
	public String gender;
	public int age;
	public int salary;
	public  EmployeeAddress  adddress;
	
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public EmployeeAddress getAdddress() {
		return adddress;
	}
	public void setAdddress(EmployeeAddress adddress) {
		this.adddress = adddress;
	}
	
	
	
	
	

}
