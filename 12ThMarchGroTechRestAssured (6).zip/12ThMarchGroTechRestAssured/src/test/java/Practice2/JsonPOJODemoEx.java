package Practice2;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class JsonPOJODemoEx {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		Employee emp=new Employee();
		emp.setName("Rohin");
		emp.setCity("Delhi");
		emp.setId(345);
		emp.setAddress("ModelTown");
		
		Employee emp1=new Employee();
		emp1.setName("Rohan");
		emp1.setCity("Guwahati");
		emp1.setId(945);
		emp1.setAddress("NewTown");
		
		Employee emp2=new Employee();
		emp2.setName("Rohani");
		emp2.setCity("Goa");
		emp2.setId(1045);
		emp2.setAddress("LakeTown");
		
		
		List<Employee> li=new ArrayList<Employee>();
		li.add(emp);
		li.add(emp1);
		li.add(emp2);
		
		ObjectMapper obj=new ObjectMapper();
	String JSONPayload=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
	System.out.println(JSONPayload);
	
	RequestSpecification req=new RequestSpecBuilder().
			setBaseUri("http://httpbin.org/post")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification res=given().log().all().spec(req).body(li);
	
	ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200)
			.expectContentType(ContentType.JSON).build();
	
	
	Response response=res.when().post().then().spec(respec).extract().response();
	
String responseString=	response.asString();
System.out.println(responseString);

ResponseBody response1=response.getBody();
JsonPath js=response1.jsonPath();

List<Employee> allEmployees=js.getList("json",Employee.class);

System.out.println();
System.out.println();

for(Employee x:allEmployees)
{
	System.out.println(x.getName());
}



		
		
		

	}

}
