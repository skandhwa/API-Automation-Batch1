
public class SqlQueries {
	
	
	
	public static String createUser()
	{
		String str="select Firstname,LastName,Address from demo.employees limit 1";
		return str;
	}
	
	
	public static String createUser1()
	{
		String str="select * from demo.employees where LastName='Das'";
		return str;
	}
	
	
	
	
	
	

}
