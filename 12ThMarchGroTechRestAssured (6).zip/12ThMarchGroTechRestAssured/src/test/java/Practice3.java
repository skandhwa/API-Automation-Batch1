import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;



public class Practice3 {
	
	@Test
	public void BearerExample()
	{
		JSONObject payload=new JSONObject();
		String Authtoken="x";
		
		given().log().all().headers("Authorization",Authtoken).body(payload.toJSONString());
		
		
	}

}
