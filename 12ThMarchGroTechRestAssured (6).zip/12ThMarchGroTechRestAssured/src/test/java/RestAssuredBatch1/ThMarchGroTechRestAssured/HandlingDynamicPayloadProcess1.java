package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;

import Utilities.PayloadNew;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class HandlingDynamicPayloadProcess1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		String Name="Harish";
		String JobRole="Engineer";
		
		
		String Response=	given().log().all().body(PayloadNew.AddPayload(Name,JobRole)).when().post("api/users")
			.then().assertThat().statusCode(201).log().all().extract().response().asString();
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		

	}

}
