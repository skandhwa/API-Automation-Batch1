package RestAssuredBatch1.ThMarchGroTechRestAssured;

public class JsonPostResponseEx {
	
	public String name;
	public String job;
//	public String salary;
	public String location;
	
	
	

}
