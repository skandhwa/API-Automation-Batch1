package RestAssuredBatch1.ThMarchGroTechRestAssured;

public class MyTest1 {

	public static void main(String[] args) {
		System.out.println("Hello");
	}

}
