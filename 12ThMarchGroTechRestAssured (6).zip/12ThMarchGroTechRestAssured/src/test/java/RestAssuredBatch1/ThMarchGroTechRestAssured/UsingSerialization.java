package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Utilities.PayloadNew;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class UsingSerialization {
	
	@Test
	public void test() throws JsonProcessingException
	{
		EmployeePojo emp=new EmployeePojo();
		emp.setName("Saurabh");
		emp.setLocation("Delhi");
		emp.setSalary(80000);
		emp.setJob("QA");
		
		ObjectMapper obj=new ObjectMapper();
		
	String employeeJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		System.out.println(employeeJson);
	
		RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification res=given().spec(req).body(employeeJson);
		
	ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
		Response response=res.when().post().then().spec(respec).extract().response();
		
		String Response=response.asString();
		System.out.println(Response);
		
		System.out.println();
		System.out.println();
		
		EmployeePojo emp2=obj.readValue(employeeJson, EmployeePojo.class);
		System.out.println("First Name is  "+emp2.getName());
		System.out.println("Job is  "+emp2.getJob());
//		System.out.println("First Name is  "+emp2.getName());
//		System.out.println("First Name is  "+emp2.getName());
	}
	

}
