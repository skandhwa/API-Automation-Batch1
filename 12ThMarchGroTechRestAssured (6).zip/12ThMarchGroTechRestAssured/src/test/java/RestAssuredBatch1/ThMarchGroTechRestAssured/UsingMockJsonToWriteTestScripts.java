package RestAssuredBatch1.ThMarchGroTechRestAssured;

import org.testng.Assert;

import Utilities.PayloadNew;
import Utilities.ReUsabaleMethods;
import io.restassured.path.json.JsonPath;


public class UsingMockJsonToWriteTestScripts {

	public static void main(String[] args) {
		
		JsonPath js1=new JsonPath(PayloadNew.AddCourse());
		
		////Print No of courses returned by API
	int x=	js1.getInt("courses.size()");
		System.out.println("The number of courese are "+x);
		
		////Print Purchase Amount
		int purchaseamount=js1.getInt("dashboard.purchaseAmount");
		System.out.println("The total purchase amount is "+purchaseamount);
		
		///print title of first course 
		
		String firstCourseTitle=js1.getString("courses[0].title");
		System.out.println("Title of First Course is  "+firstCourseTitle);
		
		///Print All course titles and their respective Prices
		
		System.out.println("The Price and Title are as Follows");
		for(int i=0;i<x;i++)
		{
		String CourseTitles=	js1.getString("courses[  "+i+ "].title"+"   " );
		int Price=	js1.getInt("   "+"courses[  "+i+ "].price");
		
		
		System.out.print(CourseTitles+"   ");
		System.out.println(Price);
		
		}
		
		///Print no of copies sold by RPA Course
		int noOfCopies=js1.getInt("courses[2].copies");
		
		System.out.println("The number of Copies sold by RPA is  "+noOfCopies);
		
		
		///Validate the Purchase Amount and The Dashboard Amount 
		
		int sum=0;
		for(int i=0;i<x;i++)
		{
		int Copies=	js1.getInt("courses[  "+i+ "].copies" );
		int Price=	js1.getInt("courses[  "+i+ "].price");
		int amount=Copies*Price;
		System.out.println("Individual Amounts are  "+amount);
		sum=sum+amount;
	
		}
		
		System.out.println("The Total Amout is "+sum);
		
		Assert.assertEquals(purchaseamount, sum);
		
		System.out.println("Test Case Passed");
		

	}

}