package RestAssuredBatch1.ThMarchGroTechRestAssured;

public class EmployeePojo {
	
	private String name;
	private String job;
	private double salary;
	private String location;
	
	
	public String getName() {
	return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
