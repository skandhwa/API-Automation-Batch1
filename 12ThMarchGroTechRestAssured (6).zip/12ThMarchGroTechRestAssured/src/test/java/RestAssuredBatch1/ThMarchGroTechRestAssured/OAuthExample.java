package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class OAuthExample {
	
	String AccessToken;

	@Test
	public void GenerateAccessToken()
	{
	
	
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		String CLIENT_ID="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7";
		String CLIENT_SECRET_ID="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
String Response=		given().log().all().auth().preemptive().
		basic(CLIENT_ID,CLIENT_SECRET_ID).
		param("grant_type", "client_credentials").
		when().post("/v1/oauth2/token").
		then().extract().response().asString();
		
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	AccessToken=js.getString("access_token");
	System.out.println(AccessToken);
	System.out.println();
	System.out.println();
	}
	
	
	@Test(dependsOnMethods= {"GenerateAccessToken"})
	public void AddTest()
	{
		
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		String Response2=	given().log().all().queryParam("page", 3).queryParam("page_size", 4)
			.auth().oauth2(AccessToken).when().get("v1/invoicing/invoices")
			.then().extract().response().asString();
		
		System.out.println(Response2);
		
		JsonPath js2=new JsonPath(Response2);
		System.out.println();
		System.out.println();
		
	String Href=	js2.getString("links[0].href");
	System.out.println(Href);
	System.out.println();
	System.out.println();
	
		
	}
	
	
	
	
	
	



		
		



}
