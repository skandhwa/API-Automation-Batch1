package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import java.nio.charset.Charset;
import java.util.Random;

import org.testng.Assert;

import Utilities.PayloadNew;
import Utilities.ReUsabaleMethods;

public class LibraryAPIExample1 {

	public static void main(String[] args) {
		
		
		    
		  String ISBN=ReUsabaleMethods.RandomStringValue();
		  int AISLE=ReUsabaleMethods.RandomNumberGen();

		
		RestAssured.baseURI="http://216.10.245.166";
		
		
		
	String Response=	given().log().all().body(PayloadNew.AddBook(ISBN,AISLE)).
		when().post("Library/Addbook.php")
		.then().extract().response().asString();
	
	System.out.println(Response);
	
	String ActualBookID=ISBN+AISLE;
	System.out.println("Actual Book ID is "+ActualBookID);
	
	JsonPath js1=ReUsabaleMethods.rawtoJson(Response);
	
	String ExpectedBookID=js1.getString("ID");
	
	Assert.assertEquals(ActualBookID, ExpectedBookID);
	System.out.println("Test Case Passed");
	
	
		
		
		
		

	}

}
