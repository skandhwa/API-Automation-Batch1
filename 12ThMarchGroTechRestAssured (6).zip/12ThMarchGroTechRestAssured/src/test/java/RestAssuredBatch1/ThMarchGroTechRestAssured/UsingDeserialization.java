package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.PayloadNew;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class UsingDeserialization {
	
	@Test
	public void test()
	{
		JSONObject payload=new JSONObject();
		
		payload.put("name", "tim");
		payload.put("job", "leader");
		//payload.put("Salary", "76000");
		payload.put("location", "Delhi");
		
		RestAssured.baseURI="http://httpbin.org/post";
	Response response=	given().log().all().when().post().then().extract().response();
		ResponseBody obj=response.getBody();
		System.out.println(obj);
		
		
	    
	    JsonPostResponseEx obj1=obj.as(JsonPostResponseEx.class);
	    Assert.assertEquals(obj1.name, "tim","Validating the Name");
	    Assert.assertEquals(obj1.job, "leader","Validating the Job");
	   // Assert.assertEquals(obj1.salary,"76000","Validating the Salary");
	    Assert.assertEquals(obj1.location,"Delhi","Validating the location");
	}
	
	
	

}
