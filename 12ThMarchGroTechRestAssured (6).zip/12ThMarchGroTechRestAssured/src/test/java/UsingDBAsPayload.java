import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
public class UsingDBAsPayload {
	
	
	@Test
	public void runTest() throws SQLException
	{
		
		RestAssured.baseURI="https://httpbin.org/post";
		
		Map<Object,Object> mp=new HashMap<Object,Object>();
		mp.put("Firstname",DatabaseConnection.getDatafromDB(1));
		mp.put("Lastname",DatabaseConnection.getDatafromDB(2));
		mp.put("Address",DatabaseConnection.getDatafromDB(3));
		
		
		
	String Response=	given().log().all().body(mp).when().post().then().extract().response().asString();
		
		System.out.println(Response);
		
		
	}
	

}
