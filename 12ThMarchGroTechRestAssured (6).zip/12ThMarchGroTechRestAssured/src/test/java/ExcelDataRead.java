import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelDataRead {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	public ExcelDataRead(String excelPath,String sheetName) throws IOException
	{
		workbook=new XSSFWorkbook(excelPath);
		sheet=workbook.getSheet(sheetName);		
	}
	
	@Test
	public static void getRowCount() throws IOException
	{
	
//	String excelPath="./data/TestData1.xlsx";
//	XSSFWorkbook workbook=new XSSFWorkbook(excelPath);
//	XSSFSheet sheet=workbook.getSheetAt(0);
	int rowcount=sheet.getPhysicalNumberOfRows();
	System.out.println("Total number of rows are "+rowcount);
	
	}
	@Test
	public static Object getCellData(int rownum,int colnum) throws IOException
	{
		//String excelPath="./data/TestData1.xlsx";
//		XSSFWorkbook workbook=new XSSFWorkbook(excelPath);
//		XSSFSheet sheet=workbook.getSheetAt(0);
//	String value=	sheet.getRow(rownum).getCell(colnum).getStringCellValue();
//	return value;
	
	
	
		
	DataFormatter formatter=new DataFormatter();
	Object value=	formatter.formatCellValue(sheet.getRow(rownum).getCell(colnum));
	return value;
	
	
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
