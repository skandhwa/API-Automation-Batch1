import org.testng.annotations.Test;

public class NewLatestPractice {
	
	@Test
	public void test()
	{
		
	}
	
	
	

}
