import java.io.IOException;

import org.testng.annotations.Test;

public class ExcelUtilTest {

	
	@Test
	public static void test() throws IOException {
		
//		String excelPath="./data/TestData1.xlsx";
//		String sheetName="Sheet1";
//		ExcelDataRead excel=new ExcelDataRead(excelPath,sheetName);
//		excel.getRowCount();
//		excel.getCellCount(1, 0);
//		excel.getCellCount(1, 1);
//		excel.getCellCount(2, 1);
//		excel.getCellCount(2, 2);
		
		
		
		

	}

}
