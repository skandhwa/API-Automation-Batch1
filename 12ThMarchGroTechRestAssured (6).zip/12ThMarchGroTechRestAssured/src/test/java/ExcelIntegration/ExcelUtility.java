package ExcelIntegration;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelUtility {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	ExcelUtility(String excelPath,String sheetName) throws IOException
	{
		workbook=new XSSFWorkbook(excelPath);
		sheet=workbook.getSheet(sheetName);
		int x=sheet.getPhysicalNumberOfRows();
		
	}
	
	
	
	
	@Test
	public static Object getTestData(int rownum,int colnum) throws IOException
	{
		
		//FileInputStream fis=new FileInputStream();
		
		
//		String value=sheet.getRow(1).getCell(2).getStringCellValue();
//		System.out.println(value);
		
		DataFormatter formatter=new DataFormatter();
	Object value=	formatter.formatCellValue(sheet.getRow(rownum).getCell(colnum));
	return value;
	
		
		
		
		
	}
	
	
	

}
