package ExcelIntegration;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CreateUser {
	
	@Test
	public void createUser() throws IOException
	{
		
		
		
		String excelPath="src\\test\\java\\TestData\\TestData1.xlsx";
		String sheetName="Sheet1";
		ExcelUtility obj=new ExcelUtility(excelPath,sheetName);
		RestAssured.baseURI="https://httpbin.org/post";
		Map<Object,Object>mp=new HashMap<Object,Object>();
		
		mp.put("firstname",obj.getTestData(1,0));
		mp.put("lastname",obj.getTestData(1,1));
		mp.put("ID",obj.getTestData(1,2));
		
		
		
	String Response=	given().log().all().body(mp).
		when().post().then().extract().response().asString();
	System.out.println(Response);
		
		
		
		
		
		
		
	}
	
	
	

}
