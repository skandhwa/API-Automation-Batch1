import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class UsingDBtoExtractData {
	
	@Test
	public void test() throws SQLException
	{
		RestAssured.baseURI="https://httpbin.org/post";
		Map<Object,Object> mp=new HashMap<Object,Object>();
		mp.put("firstname",DatabaseConnection.getDatafromDB(1));
		mp.put("lastname",DatabaseConnection.getDatafromDB(2));
		mp.put("address",DatabaseConnection.getDatafromDB(3));
		mp.put("city",DatabaseConnection.getDatafromDB(4));
		mp.put("salary",DatabaseConnection.getDatafromDB(5));
		
		
	String Response=	given().log().all().body(mp).when().post().then().extract().response().asString();
		System.out.println(Response);
	}
	
	

}
