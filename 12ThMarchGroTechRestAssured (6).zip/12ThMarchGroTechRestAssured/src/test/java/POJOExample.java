import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class POJOExample {
	
	@Test
	public void AddEmployee() throws JsonProcessingException
	{
		Employee emp1=new Employee();
		emp1.setFirstname("Mahesh");
		emp1.setLastname("Mehra");
		emp1.setGender("Male");
		emp1.setAge(22);
		emp1.setSalary(450000);
		ObjectMapper obj=new ObjectMapper();
		String employeeJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp1);
		System.out.println(employeeJSON);
		
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("http://httpbin.org/post")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification res=given().log().all().spec(req).body(employeeJSON);
		
		ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).build();
		
		
		Response response=res.when().post().then().spec(respec).extract().response();
		
	String responseString=	response.asString();
	System.out.println(responseString);
	
	Employee emp2=obj.readValue(employeeJSON, Employee.class);
	System.out.println("FirstName is" +emp2.getFirstname());
	System.out.println("LastName is" +emp2.getLastname());
		
		
		
		
		
		
		
	}
	
	
	

}
