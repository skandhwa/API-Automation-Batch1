import java.util.ArrayList;
import java.util.List;

public class JsonArrayPOJODemo {
	
	public void createEmployeeJSONArray()
	{
		Employee emp=new Employee();
		 emp.setStreet("ABCD");
		 emp.setCity("Kolkata");
		 emp.setPincode(713304);
		 emp.setState("WestBengal");
		 
		 
		 
		 
		 EmployeeAddress emp2=new EmployeeAddress();
		 emp.setStreet("DEFG");
		 emp.setCity("Delhi");
		 emp.setPincode(813304);
		 emp.setState("NCR");	 
		 
		 EmployeeAddress emp3=new EmployeeAddress();
		 emp.setStreet("UIFC");
		 emp.setCity("Jaipur");
		 emp.setPincode(913304);
		 emp.setState("YUR");	 
		 
		 
		 List<Employee> li=new ArrayList<Employee>();
		li.addAll(emp);
		
		
		 
		 
		 
		 }

}
