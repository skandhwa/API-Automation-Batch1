import java.sql.*;

import org.testng.annotations.Test;
public class DatabaseConnection {
	
	
	
	
	
		public static Object getDatafromDB(int x) throws SQLException {
			
			Connection myConn = null;
			Statement myStmt = null;
			ResultSet myRs = null;
			Object obj=null;
			try {
				
myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "student" , 
		"Kitkat@19");
				
System.out.println("Database connection successful!\n");
				
				
myStmt = myConn.createStatement();
				
				
myRs = myStmt.executeQuery(SqlQueries.createUser1());
				
				while (myRs.next()) {
					obj=	myRs.getString(x);
					
					System.out.println(obj);
					
								}			}
			catch (Exception exc) 
			{
				exc.printStackTrace();
			}
			finally 
			{
				if (myRs != null) 
				{
					myRs.close();
				}
				
				if (myStmt != null) 
				{
					myStmt.close();
				}
				
				if (myConn != null) 
				{
					myConn.close();
				}
			}
			
			return obj;
			
			
			
			
			

			
		}
		
}


