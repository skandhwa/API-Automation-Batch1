
public class JsonPostReponseExample {
	
	
	
	/*{
    "name": "morpheus",
    "job": "leader",
    "id": "318",
    "createdAt": "2024-03-24T06:10:20.132Z"
}*/
	
	public String name;
	public String job;
	public String id;
	public String createdAt;
	
	

}
