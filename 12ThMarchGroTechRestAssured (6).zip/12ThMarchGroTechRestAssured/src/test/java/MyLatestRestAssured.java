
public class MyLatestRestAssured {

	public static void main(String[] args) {
		
		
		
		
	}

}
