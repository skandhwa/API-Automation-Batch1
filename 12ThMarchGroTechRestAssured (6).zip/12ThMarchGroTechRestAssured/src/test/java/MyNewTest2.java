import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MyNewTest2 {
	

	
	@Test
	public void test1() throws IOException
	{
		
		String excelPath="./data/TestData1.xlsx";
		String sheetName="Sheet1";
		ExcelDataRead excel=new ExcelDataRead(excelPath,sheetName);		
		RestAssured.baseURI="https://httpbin.org/post";
		Map<Object,Object> mp=new HashMap<Object,Object>();
		mp.put("Firstname",excel.getCellData(1, 0));
		mp.put("Lastname",excel.getCellData(1, 1));	
		mp.put("EmployeeId",excel.getCellData(1, 2));		
	    String Response=given().log().all().body(mp).when().post().then().extract().response().asString();
		System.out.println(Response);
	
		
	}
	

}
