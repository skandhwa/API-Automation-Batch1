package SerializationDeserialization;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Utilities.PayloadNew;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class MyTest {
	
	@Test
	public void test() throws JsonProcessingException
	{
		Employee obj=new Employee();
		obj.setCity("kolkata");
		obj.setName("Mohan");
		obj.setState("WB");
		obj.setPincode(713304);
		
		Employee obj1=new Employee();
		obj1.setCity("Delhi");
		obj1.setName("Rohan");
		obj1.setState("NCR");
		obj1.setPincode(715604);
		
		Employee obj2=new Employee();
		obj2.setCity("Hyderabad");
		obj2.setName("Sohan");
		obj2.setState("TS");
		obj2.setPincode(845678);
		
		List<Employee> li=new ArrayList<Employee>();
		li.add(obj);
		li.add(obj1);
		li.add(obj2);
		
		ObjectMapper objmapper=new ObjectMapper();
	String JsonPayload=	objmapper.writerWithDefaultPrettyPrinter().writeValueAsString(li);
	
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification res=given().spec(req).body(JsonPayload);
	
ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
	Response response=res.when().post().then().spec(respec).extract().response();
	
	String Response1=response.asString();
	System.out.println();
	System.out.println();
	System.out.println(Response1);
	
	
ResponseBody res1=	response.getBody();


JsonPath js1=res1.jsonPath();


List<Employee> allEmployees=js1.getList("json",Employee.class);
System.out.println();
System.out.println();

System.out.println();
System.out.println();

for(Employee x:allEmployees)
{
	System.out.println(x.getName());
	
	System.out.println(x.getCity());
}

		
		
		
		
		
		
		
		
	}
	

}
