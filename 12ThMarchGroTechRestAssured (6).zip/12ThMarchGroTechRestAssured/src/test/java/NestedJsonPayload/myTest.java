package NestedJsonPayload;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class myTest {
	
	@Test
	public void mytest() throws JsonProcessingException
	{
		EmployeeAddress empAddress=new EmployeeAddress();
		empAddress.setCity("kolkata");
		empAddress.setPincode(700033);
		empAddress.setState("WB");
		empAddress.setStreet("tollygunge");
		
		EmployeePojo emp1=new EmployeePojo();
		emp1.setFirstName("Rohan");
		emp1.setLastName("Roy");
		emp1.setAge(32);
		emp1.setGender("male");
		emp1.setSalary(80000);
		emp1.setAddress(empAddress);
		
		ObjectMapper obj=new ObjectMapper();
	String JSONPayload=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp1);
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("http://httpbin.org/post")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification res=given().spec(req).body(JSONPayload);
	
ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(200).build();
	Response response=res.when().post().then().spec(respec).extract().response();
	
	String Response1=response.asString();
	System.out.println();
	System.out.println();
	System.out.println(Response1);
		
		
		
		
	}
	

}
