import java.io.File;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class UploadFile {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="http://httpbin.org/post";
		
		File file=new File("D:\\TestUploadRest.txt");
		
	String path=	file.getPath();
	System.out.println(path);
	String response=	given().log().all().header("Content-Type","multipart/form-data").
			multiPart("file",file).
		when().post().then().extract().response().asString();
	System.out.println(response);
		
		

	}

}
