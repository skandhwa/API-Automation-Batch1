package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import org.json.simple.JSONObject;

import Utilities.PayloadNew;

public class BearerTokenAuthentication {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://gorest.co.in/public/v2/users";
		String AuthToken="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
		
		JSONObject payload=new JSONObject();
		payload.put("name","morpheus");
		payload.put("gender","male");
		payload.put("email","dasdsa12@gmail.com");
		payload.put("status","active");
		
		String Response=	given().log().all().body(payload.toJSONString()).headers("Authorization",AuthToken)
				.headers("Content-Type","application/json")
				.when().post().then().
				extract().response().asString();
		
		System.out.println(Response);
				
		

	}

}
