package RestAssuredBatch1.ThMarchGroTechRestAssured;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utilities.PayloadNew;
import Utilities.ReUsabaleMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class UsingDataProviderToPassMultipleValues {
	
	@DataProvider(name="booksdata")
	public Object [][]  getData()
	{
		return new Object[][]
				
				{
			
			{"xyzd",5678},
			{"tyurf",9876},
			{"xyyd",5678},
			{"tyuwf",9876},
			
					
				};

	}
	@Test(dataProvider="booksdata")
	public void AddMultipleBook(String ISBN,int AISLE)
	{
		RestAssured.baseURI="http://216.10.245.166";
	String Response=	given().log().all().body(PayloadNew.AddBook(ISBN, AISLE)).when().post("Library/Addbook.php")
		.then().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js1=ReUsabaleMethods.rawtoJson(Response);
	String ID=js1.getString("ID");
	System.out.println(ID);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
		
	
	

}
