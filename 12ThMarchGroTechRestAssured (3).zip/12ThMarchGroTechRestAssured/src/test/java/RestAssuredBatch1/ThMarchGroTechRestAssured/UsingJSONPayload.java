package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.json.simple.JSONObject;

public class UsingJSONPayload {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in/";
		
		JSONObject payload=new JSONObject();
		payload.put("name","morpheus");
		payload.put("job","leader");
		
		
	Response response=	given().log().all().body(payload.toJSONString()).when().post("api/users").then().extract().response();
		System.out.println(response.asPrettyString());

	}

}
