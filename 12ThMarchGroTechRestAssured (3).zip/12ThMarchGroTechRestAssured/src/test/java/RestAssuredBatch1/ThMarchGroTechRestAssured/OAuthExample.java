package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;

public class OAuthExample {

	public static void main(String[] args) 
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		String CLIENT_ID="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7";
		String CLIENT_SECRET_ID="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
String Response=		given().log().all().auth().
		basic(CLIENT_ID,CLIENT_SECRET_ID).when().get("/v1/oauth2/token").then().extract().response().asString();
		
	System.out.println(Response);
		
		

	}

}
