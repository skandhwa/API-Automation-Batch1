package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class CrashUsingQueryParameter {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		int ActualId=8;
		
		String Response=	given().log().all().headers("Connection","keep-alive")
				.queryParam("page", "2")
				
				
			.when().get("api/users")
			.then().log().all().assertThat().statusCode(200).
			
			header("Content-Type","application/json; charset=utf-8").extract().
			response().asString();
		
		System.out.println(Response);
		
		
		JsonPath js=new JsonPath(Response);
	int ExpectedId=	js.getInt("data[1].id");
	
	Assert.assertEquals(ActualId, ExpectedId);
	System.out.println("Test Case Passed");
	
		
		
		

	}

}
