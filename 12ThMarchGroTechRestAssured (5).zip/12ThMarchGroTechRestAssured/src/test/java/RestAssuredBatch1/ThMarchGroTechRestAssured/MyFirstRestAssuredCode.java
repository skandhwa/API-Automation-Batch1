package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class MyFirstRestAssuredCode {

	public static void main(String[] args) {
		
		
		///given--->my input section of code
		
		//when--->method name for the request
		
		//then--->Validation 
		
		String ActFirstName="Janet";
		String ActLastName="Weaver";
		
		RestAssured.baseURI="https://reqres.in";
		
//	String Response=	given().log().all().headers("Connection","keep-alive")
//		.when().get("api/users/2")
//		.then().log().all().extract().response().asString();
//	
//	System.out.println(Response);
		
		
	String Response=	given().log().all().headers("Connection","keep-alive")
			.when().get("api/users/2")
			.then().log().all().
			assertThat().statusCode(200)
			.body("data.id",equalTo(2)).
			headers("Connection","keep-alive").
			extract().response().asString();
		
		System.out.println(Response);
		
		
		
		JsonPath js=new JsonPath(Response);
	String ExpFirstName=	js.getString("data.first_name");
	
	String ExpLastName=js.getString("data.last_name");
	
	
	
	Assert.assertEquals(ActFirstName, ExpFirstName);
	Assert.assertEquals(ActLastName, ExpLastName);
	
	System.out.println("All Assertions Passed");
		
			
	
		
		
		
	}

}
