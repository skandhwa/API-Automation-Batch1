package RestAssuredBatch1.ThMarchGroTechRestAssured;

import java.io.File;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class FileUploadinRestAssured {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://httpbin.org/post";
		File file=new File("‪C:\\Users\\saura\\OneDrive\\Pictures\\Test123.txt");
		
	String Response=    given().log().all().header("Content-Type","multipart/form-data").
			multiPart("file",file).
	    when().
	    post().then().log().all().extract().response().asString();
	
	System.out.println(Response);
		
	
	
		
		

	}

}
