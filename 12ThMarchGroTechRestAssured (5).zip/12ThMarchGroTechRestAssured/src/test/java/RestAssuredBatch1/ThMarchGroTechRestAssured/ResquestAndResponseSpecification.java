package RestAssuredBatch1.ThMarchGroTechRestAssured;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import Utilities.PayloadNew;

public class ResquestAndResponseSpecification {
	
	@Test
	public void test1()
	{
	
	RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in")
			.setContentType(ContentType.JSON).build();
	
	RequestSpecification res=given().spec(req).body(PayloadNew.AddPayload("Manish", "QA"));
	
ResponseSpecification respec=new ResponseSpecBuilder().expectStatusCode(201).build();
	Response response=res.when().post("api/users").then().spec(respec).extract().response();
	
	String Response=response.asString();
	System.out.println(Response);
	
	}
	
	
	

}
