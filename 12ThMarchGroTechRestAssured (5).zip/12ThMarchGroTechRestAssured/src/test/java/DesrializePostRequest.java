import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;


public class DesrializePostRequest {

	
		@Test
		public void createUser()
		{
			
			RestAssured.baseURI="https://reqres.in/";
			
			JSONObject payload=new JSONObject();
			payload.put("name","morpheus");
			payload.put("job","leader");
			
			
		Response response=	given().log().all().headers("Content-Type","application/json").
				body(payload.toJSONString()).
				when().post("api/users").then().log().all().extract().response();
	ResponseBody obj=	response.getBody();
	
	
	
	JsonPostReponseExample responseclass=obj.as(JsonPostReponseExample.class);
	
	
	Assert.assertEquals(responseclass.name, "morpheus","check for name");
	Assert.assertEquals(responseclass.job, "leader","check for Job");

			
		}
		

	

}
