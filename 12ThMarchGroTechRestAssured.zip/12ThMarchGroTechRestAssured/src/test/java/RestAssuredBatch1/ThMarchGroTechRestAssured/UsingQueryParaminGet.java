package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import io.restassured.RestAssured;

public class UsingQueryParaminGet {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=	given().log().all().headers("Connection","keep-alive")
				.queryParam("page", "2")
				
				
				.when().get("api/users")
				
				.then().log().all().
				assertThat().statusCode(200).
				
				headers("Connection","keep-alive").
				extract().response().asString();
			
			System.out.println(Response);
			
	}

}
