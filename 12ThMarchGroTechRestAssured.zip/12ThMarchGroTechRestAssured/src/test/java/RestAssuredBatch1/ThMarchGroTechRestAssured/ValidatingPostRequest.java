package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class ValidatingPostRequest {

	public static void main(String[] args) {
		
		String Today_Date="2024-03-13";
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().body(Payload.AddName()).when().post("api/users")
		.then().assertThat().statusCode(201).log().all().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String ID=js.getString("id");
	System.out.println(ID);
	
	String CreatedDate=js.getString("createdAt");
	System.out.println(CreatedDate);
	String []Date=CreatedDate.split("T");
	System.out.println(Date[0]);
	
	String ExpectedDate=Date[0];
	
	Assert.assertEquals(Today_Date, ExpectedDate);
	
	System.out.println("Test Case Passed");
	
	
	
	
	
		
	
		
		
		
		

	}

}
