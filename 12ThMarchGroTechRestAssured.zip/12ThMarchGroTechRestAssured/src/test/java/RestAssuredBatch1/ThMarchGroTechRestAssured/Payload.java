package RestAssuredBatch1.ThMarchGroTechRestAssured;

public class Payload {
	
	public static String AddName()
	
	{
		return "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}";
		
		
		
	}
	
	

}
