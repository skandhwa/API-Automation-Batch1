package Constants;

public class constant {
	
	
	public static final String PropertyFilePath="src\\main\\java\\Global.properties";
	
	
	

}
