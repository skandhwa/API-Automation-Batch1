package RestAssuredBatch1.ThMarchGroTechRestAssured;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class PassingRequestThroughMap {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		Map<String,Object> mp=new HashMap<String,Object>();
		
		mp.put("name","mahesh");
		mp.put("id",5);
		mp.put("address","Kolkata");
		mp.put("salary",76000);
		
		
Map<String,Object> mp2=new HashMap<String,Object>();
		
		mp2.put("name","Ramesh");
		mp2.put("id",51);
		mp2.put("address","Delhi");
		mp2.put("salary",78000);
		
Map<String,Object> mp3=new HashMap<String,Object>();
		
		mp3.put("name","samresh");
		mp3.put("id",54);
		mp3.put("address","Kochi");
		mp3.put("salary",98000);
		
		
		
List<Map<String,Object>> jsonpayload=new ArrayList();	

jsonpayload.add(mp);
jsonpayload.add(mp2);
jsonpayload.add(mp3);

System.out.println(jsonpayload);



		
		
	String Response=	given().log().all().body(jsonpayload).headers("Content-Type","application/json").
		when().post("api/users").then().extract().response().asString();
	System.out.println(Response);
		
	
		

	}

}
