package RestAssuredBatch1.ThMarchGroTechRestAssured;

import static io.restassured.RestAssured.*;

import java.util.List;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;

public class ValidatingXMLResponse {

	public static void main(String[] args) {
		
		RestAssured.baseURI="http://samplerestapi.com";
String Response=		given().log().all().when().get("api/petslover").then().
extract().response().asString();
		
	System.out.println(Response);
	
	String h="PetsLoverInformationResponse.travelers";
	
	XmlPath obj=new XmlPath(Response);
	
	List<String> li=obj.getList("PetsLoverInformationResponse.travelers.PetsloverInformation");
	int x=li.size();
	System.out.println("The total number of traveller are "+x);
	for(String y:li)
	{
		System.out.println(y);
	}
	
	
	System.out.println();
	System.out.println();
	
	
	List<String> li2=obj.getList("PetsLoverInformationResponse.travelers.PetsloverInformation.name");
	int z=li2.size();
	System.out.println("The total number of traveller are "+x);
	for(String u:li2)
	{
		System.out.println(u);
	}
	System.out.println();
	System.out.println();
	
	String IDSecond=obj.getString ("PetsLoverInformationResponse.travelers.PetsloverInformation[3].id");
	System.out.println("The sond ID is  "+IDSecond);

	}

}
