package RestAssuredBatch1.ThMarchGroTechRestAssured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;


public class APICrash1 {

	public static void main(String[] args) {
		
		
		//given---->all input details 
		
		//when---->which method we are using to submit api 
		
		//then ---->validating the response
		
		String ActualFname="Janet";
		String ActualEmail="janet.weaver@reqres.in";
		
		RestAssured.baseURI="https://reqres.in";
		
		
	String Response=	given().log().all().headers("Connection","keep-alive")
		.when().get("api/users/2")
		.then().log().all().assertThat().statusCode(200).body("data.id",equalTo(2)).
		
		header("Content-Type","application/json; charset=utf-8").extract().
		response().asString();
	
	System.out.println(Response);
	
	
	JsonPath Js=new JsonPath(Response);
String ExpFName=	Js.getString("data.first_name");

Assert.assertEquals(ActualFname, ExpFName);



String ExpEmail=Js.getString("data.email");

Assert.assertEquals(ActualEmail, ExpEmail);


System.out.println("My test Case Passed");
	
	
	
	
		
		
		
		

	}

}
