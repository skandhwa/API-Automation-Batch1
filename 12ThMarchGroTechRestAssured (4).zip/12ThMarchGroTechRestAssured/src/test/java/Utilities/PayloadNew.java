package Utilities;

public class PayloadNew {
	
	public static String AddPayload(String name,String leader)
	{
		
		String Payload="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+leader+"\"\r\n"
				+ "}";
		
		return Payload;
		
	}
	
	
	public static String AddBook(String ISBN,int aisle)
	{
		String Payload1="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with gggg\",\r\n"
				+ "\"isbn\":\""+ISBN+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}";
		
		return Payload1;
		
	}
	
	public static String  AddCourse()
	{
		String Payload2="{\r\n"
				+ "\r\n"
				+ "\"dashboard\": {\r\n"
				+ "\r\n"
				+ "\"purchaseAmount\": 910,\r\n"
				+ "\r\n"
				+ "\"website\": \"grotechminds.com\"\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "\"courses\": [\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"Selenium Python\",\r\n"
				+ "\r\n"
				+ "\"price\": 50,\r\n"
				+ "\r\n"
				+ "\"copies\": 6\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"Cypress\",\r\n"
				+ "\r\n"
				+ "\"price\": 40,\r\n"
				+ "\r\n"
				+ "\"copies\": 4\r\n"
				+ "\r\n"
				+ "},\r\n"
				+ "\r\n"
				+ "{\r\n"
				+ "\r\n"
				+ "\"title\": \"RPA\",\r\n"
				+ "\r\n"
				+ "\"price\": 45,\r\n"
				+ "\r\n"
				+ "\"copies\": 10\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "\r\n"
				+ "]\r\n"
				+ "\r\n"
				+ "}\r\n"
				+ "";
		
		return Payload2;
	}
	
	
	public static String AddDetails()
	{
		String Payload4="{\"name\":\"Tenali Ramakrishna\", \r\n"
				+ "\"gender\":\"male\", \r\n"
				+ "\"email\":\"tenali.ramaertasdsae@gmail.com\",\r\n"
				+ " \"status\":\"active\"\r\n"
				+ " }";
		
		return Payload4;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
