import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;


import static io.restassured.RestAssured.*;

import java.util.List;

import org.testng.Assert;

public class SelfPractice {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="http://samplerestapi.com/api/petslover";
	String res=	given().log().all().when().get().then().extract().response().asString();
	
	System.out.println(res);
	XmlPath obj=new XmlPath(res);
	
	List<String> travellers=
			obj.getList("PetsLoverInformationResponse.travelers.PetsloverInformation");
	System.out.println(travellers.size());
	
String ID=	obj.getString
("PetsLoverInformationResponse.travelers.PetsloverInformation[0].email");
System.out.println(ID);	

List<String> travellersname=obj.getList("PetsLoverInformationResponse.travelers.PetsloverInformation.name");
	
		for(String x:travellersname)
		{
			System.out.println(x);
		}
		
	//	if(travellersname.equals(obj))
		

	}

}
