package MyJavaBasics;

public class DataTypesinJava {

	public static void main(String[] args) {
		
		long x=2343243243243243242L;
		
		int v=78;
		
		
		byte y=121;
		
		float k=123213213324324432432213213.231231223432432432321312312f;
		
		char ch='w';
		

	}

}
