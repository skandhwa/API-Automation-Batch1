package MyJavaBasics;

public class NestedForLoop {

	public static void main(String[] args) {
		
		
		for(int i=0;i<3;)///i=0,0<3//1<3//2<3
		{
			for(int j=0;j<3;)
			{
				System.out.println(i+"   "+j);///2..0///2..1///2...2
				j++;
			}
			
			i++;
		}
		
		

	}

}
