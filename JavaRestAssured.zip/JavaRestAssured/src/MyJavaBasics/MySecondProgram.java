package MyJavaBasics;

public class MySecondProgram {
	
	
	static int add(int a,int b)
	{
		int c=a+b;
		return c;
		
	}
	
	

	public static void main(String[] args) {
		
//		MySecondProgram obj=new MySecondProgram();
//	System.out.println("The Sum of two numbers are "+obj.add(12, 20));
		
	//System.out.println(add(56,78));	
		
	System.out.println(MySecondProgram.add(34, 45));	
		

	}

}
